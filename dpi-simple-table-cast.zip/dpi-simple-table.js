define(["jquery", "text!./dpi-simple-table.css"], function($, cssContent) {'use strict';
	$("<style>").html(cssContent).appendTo("head");
	return {
		initialProperties : {
			version : 1.0,
			qHyperCubeDef : {
				qDimensions : [],
				qMeasures : [],
				qInitialDataFetch : [{
					qWidth : 15,
					qHeight : 500
				}]
			}
		},
		definition : {
			type : "items",
			component : "accordion",
			items : {
				dimensions : {
					uses : "dimensions",
					min : 1
				},
				measures : {
					uses : "measures",
					min : 0
				},
				sorting : {
					uses : "sorting"
				},
				settings : {
					uses : "settings"
				},
				rawHTML : {
					label: 'Enable Raw Html',
					type: 'items',
					items : {
						html:{
						  type: "boolean",
						  component: "switch",
						  translation: "Enable Raw HTML Input",
						  ref: "htmlInput",
						  defaultValue: false,
						  trueOption: {
							  value: true,
							  translation: "properties.on"
							  },
						  falseOption: {
							  value: false,
							  translation: "properties.off"
							  },
						  show: true
						}
					}
				},
				linkOptions : {
					label: 'Link Options',
					type: 'items',
					items : {
						links:{
						  type: "boolean",
						  component: "switch",
						  translation: "Enable Links",
						  ref: "linkColumns",
						  defaultValue: true,
						  trueOption: {
							  value: true,
							  translation: "properties.on"
							  },
						  falseOption: {
							  value: false,
							  translation: "properties.off"
							  },
						  show: true
						},
						selectableLinksOption: {
						  	type: "boolean",
						  	component: "switch",
						  	translation: "Selectable Links",
							ref: "selectableLinks",
							defaultValue: false,
							trueOption: {
								value: true,
								translation: "properties.on"
								},
							falseOption: {
								value: false,
								translation: "properties.off"
								},
						 	show : function(data) {
								return data.linkColumns;
							}
						},
						customLinkLabeling: {
						  	type: "boolean",
						  	component: "switch",
						  	translation: "Custom Link Handling",
							ref: "linkLabel",
							defaultValue: false,
							trueOption: {
								value: true,
								translation: "properties.on"
								},
							falseOption: {
								value: false,
								translation: "properties.off"
								},
						 	show : function(data) {
								return data.linkColumns;
							}
						},
						delimiterOnOff: {
						  type: "boolean",
						  component: "switch",
						  translation: "Enable Delimiter",
						  ref: "delimiterSwitch",
						  defaultValue: false,
						  trueOption: {
							  value: true,
							  translation: "properties.on"
							  },
						  falseOption: {
							  value: false,
							  translation: "properties.off"
							  },
						 	show : function(data) {
								return data.linkLabel && data.linkColumns;
							}
						},
						customDelimiter: {
								ref : "delimiter",
								label : "Delimiter for Link Label",
								type : "string",
								defaultValue : '',
							 	show : function(data) {
									return data.linkLabel  && data.delimiterSwitch && data.linkColumns;
								}
						},
						staticLabelOnOff: {
						  type: "boolean",
						  component: "switch",
						  translation: "Enable Static Label",
						  ref: "labelSwitch",
						  defaultValue: false,
						  trueOption: {
							  value: true,
							  translation: "properties.on"
							  },
						  falseOption: {
							  value: false,
							  translation: "properties.off"
							  },
						 	show : function(data) {
								return data.linkLabel && data.linkColumns;
							}
						},
						customTitle: {
								ref : "customLabel",
								label : "Static title",
								type : "string",
								defaultValue : '',
							 	show : function(data) {
									return data.linkLabel  && data.labelSwitch && data.linkColumns;
								}
						}
					}
				},
				imageOptions : {
					label: 'Image Options',
					type: 'items',
					items : {
						images : {				
							  type: "boolean",
							  component: "switch",
							  translation: "Enable Embedded Images",
							  ref: "imageColumns",
							  defaultValue: true,
							  trueOption: {
								  value: true,
								  translation: "properties.on"
								  },
							  falseOption: {
								  value: false,
								  translation: "properties.off"
								  },
							  show: true
						},
						imageHeight: {
								ref : "imageHeight",
								label : "Image Height",
								type : "string",
								defaultValue : 100,
							 	show : function(data) {
									return data.imageColumns;
								}
						}
					}
				},
				CastOptions : {
					label: 'Cast Add-on',
					type: 'items',
					items : {
						FixHeader: {
							type: "boolean",
							label: "Fixed Header Effect",
							ref: "FixHeader",
							defaultValue: false,
						},
						THeader: {
							label: "Table Header Effect",
							ref: "THeaderCSS",
							component: "textarea",
							type: "string",
							defaultValue: '',
						},
						Tbody: {
							label: "Table Body Effect",
							ref: "TbodyCSS",
							component: "textarea",
							type: "string",
							defaultValue: '',
						},
		                About_TextA: {
		                            label: 'Cast Add-on for Simple Table',
		                            component: "text",
		                            },   
		                About_TextC: {
		                            label: 'by Cast Solutions',
		                            component: "link",
		                            url:"http://www.castsolutions.com.au/"
		                            },
					}
				},
			}
		},
		snapshot : {
			canTakeSnapshot : true
		},
		paint : function($element, layout) {
			var table_id_a=Math.round(Math.random()*10000);
			var table_id_b=Math.round(Math.random()*10000);
			var table_header_class=Math.round(Math.random()*10000);
			var html = "<div><table id='"+ table_id_a+ "' class='stickyHeader' style='width:99%;'><thead><div><tr id='"+ table_id_b + "' style='overflow:hidden;'>", self = this, lastrow = 0, dimcount = this.backendApi.getDimensionInfos().length;
			console.log(table_id_b);
			console.log(table_id_a);
			console.log(table_header_class);
			// handle link address and link labels depending on the link option settings
			function deriveLabels (input) {
				var address='';
				var label='';
				if(input !== undefined) {
					if (layout.linkLabel && layout.linkColumns) {
						if(layout.labelSwitch && layout.customLabel && layout.delimiterSwitch && layout.delimiter) {
							label = layout.customLabel;
							if(input.indexOf(layout.delimiter)>0) {
								address = input.slice(0,input.indexOf(layout.delimiter));
							}
							else {
								address = input;
							}						}
						else if(layout.delimiterSwitch && layout.delimiter) {
							if(input.indexOf(layout.delimiter)>0) {
								label = input.slice(input.indexOf(layout.delimiter)+1);
								address = input.slice(0,input.indexOf(layout.delimiter));
							}
							else {
								label = input;
								address = input;
							}
						}
						else if(layout.labelSwitch && layout.customLabel) {
							label = layout.customLabel;
							address = input;
						}
						else {
							label = input;
							address = input;
						}
					}
					else {
						label = input;
						address = input;
					}
				}
				return [label, address];
			}


			//render titles
			$.each(this.backendApi.getDimensionInfos(), function(key, value) {
				html += '<th class="'+table_header_class+'" align="left" style="background:white;'+layout.THeaderCSS+'">' + value.qFallbackTitle + '</th>';
			});
			$.each(this.backendApi.getMeasureInfos(), function(key, value) {
				html += '<th class="'+table_header_class+'" align="left" style="background:white;'+layout.THeaderCSS+'">' + value.qFallbackTitle + '</th>';
			});
			html += "</tr></div></thead><tbody>";
			if(layout.FixHeader==true){
				html += '<tr>';
				$.each(this.backendApi.getDimensionInfos(), function(key, value) {
					//html += '<td class="tbfd" align="left">' + value.qFallbackTitle + '</td>';
					html += '<td class="tbfd" align="left" style="'+layout.THeaderCSS+';color:transparent;">' + value.qFallbackTitle + '</td>';
				});
				$.each(this.backendApi.getMeasureInfos(), function(key, value) {
					html += '<td class="tbfd" align="left" style="'+layout.THeaderCSS+';color:transparent;">' + value.qFallbackTitle + '</td>';
					//html += '<td class="tbfd" align="left">' + value.qFallbackTitle + '</td>';
				});			
				html += '</tr>';
			}
			//render data
			this.backendApi.eachDataRow(function(rownum, row) {
				lastrow = rownum;
				html += '<tr>';
				$.each(row, function(key, cell) {
					if(cell.qIsOtherCell) {
						cell.qText = self.backendApi.getDimensionInfos()[key].othersLabel;
					}
					html += "<td style='"+layout.TbodyCSS+"' class='";
					if(!isNaN(cell.qNum)) {
						html += "numeric ";
					}

					if (!layout.htmlInput) {
						var labelAddressArray = deriveLabels(cell.qText);
						var label = labelAddressArray[0];
						var address = labelAddressArray[1];
					
						// toggle selectable for links, so that when you click a link, it won't necessarily drill to it
						var selectable = '';

						if (layout.selectableLinks) {
							selectable = 'selectable'
						}
						else {
							if( ~address.slice(0,4).toLowerCase()==='http' ||
								~address.slice(0,3).toLowerCase()==='www' ||
								~address.toLowerCase().indexOf('.com') || 
								~address.toLowerCase().indexOf('.net')|| 
								~address.toLowerCase().indexOf('.edu') || 
								~address.toLowerCase().indexOf('.org') ||
								~address.toLowerCase().indexOf('.gov')
								) 
							{
								selectable = '';
							} 
							else {
									selectable = 'selectable';
							}
						}
					}
					else {
						var selectable = 'selectable';
						var address = '';
						var label = '';
					}
					// enable selectable
					if(key < dimcount && cell.qElemNumber > -1) {
						html += selectable + "' data-value='" + cell.qElemNumber + "' data-dimension='" + key + "'";
					} else {
						html += "'";
					}
						if(label !== undefined) {
							if (!layout.htmlInput) {
								//if just links is selected, check for links and convert
								if(layout.linkColumns && !layout.imageColumns){
									if(address.slice(0,4).toLowerCase()==='http'){
										html += '> <a href="' + address + '" target="_blank">' + label + '</a></td>';
									}
									else if(address.slice(0,3).toLowerCase()==='www'){
										html += '> <a href="http://' + address + '" target="_blank">' + label + '</a></td>';
									}
									else if(address.toLowerCase().indexOf('.com')>0 || address.toLowerCase().indexOf('.net')>0 || address.toLowerCase().indexOf('.edu')>0 || address.toLowerCase().indexOf('.gov')>0) {
										html += '> <a href="' + address + '" target="_blank">' + label + '</a></td>';
									}
									else{
										html += '>' + address + '</td>';
									}
								}
								//if just images is selected, check for images and convert
								else if(layout.imageColumns && !layout.linkColumns){
									if(~address.toLowerCase().indexOf('img.') || ~address.toLowerCase().indexOf('.jpg') || ~address.toLowerCase().indexOf('.gif') || ~address.toLowerCase().indexOf('.png')){
									    html += '> <img src="' + address + '" height=' + layout.imageHeight + '></td>';
									}
									else{
										html += '>' + address + '</td>';
									}
								}
								//if both images and links are selected, if an image, convert and add a link
								//if not an image, just convert to link
								else if(layout.imageColumns && layout.linkColumns){
									if(~address.toLowerCase().indexOf('img.') || ~address.toLowerCase().indexOf('.jpg') || ~address.toLowerCase().indexOf('.gif') || ~address.toLowerCase().indexOf('.png')){
									    html += '> <a href="' + address + '" target="_blank"><img src="' + label + '"" height=' + layout.imageHeight + '></a></td>';
									}
									else if(address.slice(0,4).toLowerCase()==='http'){
										html += '> <a href="' + address + '" target="_blank">' + label + '</a></td>';
									}
									else if(address.slice(0,3).toLowerCase()==='www'){
										html += '> <a href="http://' + address + '" target="_blank">' + label + '</a></td>';
									}
									else if(address.toLowerCase().indexOf('.com')>0 || address.toLowerCase().indexOf('.net')>0 || address.toLowerCase().indexOf('.edu')>0 || address.toLowerCase().indexOf('.gov')>0) {
										html += '> <a href="' + address + '" target="_blank">' + label + '</a></td>';
									}
									else{
										html += '>' + address + '</td>';
									}
								}
							  	//otherwise, no formatting
								else{
								html += '>' + address + '</td>';
								}
							}
							else {
								html += '>' + cell.qText + '</td>';
							}
						// value is undefined, fill with null value
						}
						else{
							html += '>' + '</td>';
						}

				});
				html += '</tr>';			    
			});
			html += "</tbody></table></div>";


		if(layout.FixHeader==true){
		$element.ready(function(){
		var table = $("#"+table_id_a);
		var tableClone = $(table).clone(true).empty().removeClass('stickyHeader');
		var theadClone = $(table).find('thead').clone(true);
		var stickyHeader =  $('<div></div>').addClass('stickyHeader hide').attr('aria-hidden', 'true');
		stickyHeader.append(tableClone).find('table').append(theadClone);
		$(table).after(stickyHeader);
		
		var tableHeight = $(table).height();
		var tableWidth = $(table).width() + Number($(table).css('padding-left').replace(/px/ig,"")) + Number($(table).css('padding-right').replace(/px/ig,"")) + Number($(table).css('border-left-width').replace(/px/ig,"")) + Number($(table).css('border-right-width').replace(/px/ig,""));
		//console.log(tableWidth)
		var headerCells = $(table).find('thead th');
		var headerCellHeight = $(headerCells[0]).height();
		var no_fixed_support = false;
		if (stickyHeader.css('position') == "absolute") {
			no_fixed_support = true;
		}
		
		var stickyHeaderCells = table.find('th');
		//stickyHeader.css('width', tableWidth);
		var n_sum=0;

		//$('.tbhd').css('width', tableWidth)
		var cellWidths = [];
		for (var i = 0, l = headerCells.length; i < l; i++) {
			cellWidths[i] = $(headerCells[i]).width();
			n_sum=n_sum+$(headerCells[i]).width();
		}
		//console.log($(headerCells[1]).width());
		//console.log($(headerCells[0]).width());

		$("#"+table_id_b).css("position","fixed");
		for (var i = 0, l = headerCells.length; i < l; i++) {
			$(stickyHeaderCells[i]).css('width', cellWidths[i]);
		}

		if(n_sum>=$element.width()){
			$('#'+table_id_b).css('width',$element.width()+'px');

		};

		$('.tbfd').css('color',$('.tbfd').css('background'));
		console.log($('.tbfd').css('background'));
		console.log("nsum:"+n_sum);
		console.log($element.width());
		//$('#divvv2').scrollTo(30,0);
		//$("."+table_header_class).css("background","white");



		var cutoffTop = $(table).offset().top;
		var cutoffBottom = tableHeight + cutoffTop - headerCellHeight;
		});
	}

			$element.html(html);
		  	$element.find('.selectable').on('qv-activate', function() {
				if(this.hasAttribute("data-value")) {
					var value = parseInt(this.getAttribute("data-value"), 10), dim = parseInt(this.getAttribute("data-dimension"), 10);
					self.selectValues(dim, [value], true);
					$element.find("[data-dimension='"+ dim +"'][data-value='"+ value+"']").toggleClass("selected");
				}
			});
		}
	};
});







